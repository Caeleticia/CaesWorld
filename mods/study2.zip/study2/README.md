# 妙妙生物第二弹

- 模组 id：`study2`
- 版本：1
- 内容：单位 3 · 技能 11 · 效果 5

添加了神奇的妙妙生物

## 单位与卡面

- `study2_unit_wjc` · 削肾客 → images/wjc.png
- `study2_unit_ct` · 历史学者 → images/ct.png
- `study2_unit_slime` · 呵了个呵 → images/slime.jpg

## 技能与图标

- `study2_skill_zc` · 战场上可没有给你休息的时间 → （暂无图标）
- `study2_skill_xs` · 削肾！ → （暂无图标）
- `study2_skill_pgxf` · 瓶盖戏法 → （暂无图标）
- `study2_skill_hsm` · 好似喵 → （暂无图标）
- `study2_skill_sl` · 史论 → （暂无图标）
- `study2_skill_ca` · 尘埃 → （暂无图标）
- `study2_skill_bp` · 被抛 → （暂无图标）
- `study2_skill_wwxwxg` · 无.无限.无限光 → （暂无图标）
- `study2_skill_wxcs` · 物质-形成-创造-神性 → （暂无图标）
- `study2_skill_cz` · 此在 → （暂无图标）
- `study2_skill_zscz` · 在世存在 → （暂无图标）

## 效果与图标

- `study2_effect_rdtp` · 弱点突破 → （暂无图标）
- `study2_effect_pg` · 瓶盖 → （暂无图标）
- `study2_effect_sl` · 史论 → （暂无图标）
- `study2_effect_cl` · 沉沦 → （暂无图标）
- `study2_effect_wg` · 王冠 → （暂无图标）

## 卡面规则

单位卡面放在 `images/`，文件名取单位 id 的最后一个字段，扩展名不限（png / jpg / webp…）。
例如 `study_unit_littleempire` 对应 `images/littleempire.jpg`。

## 图标规则

技能图标放在 `icons/skill/`，效果图标放在 `icons/effect/`；文件名取 id 的最后一个字段，扩展名不限。
例如 `study_skill_choco` 对应 `icons/skill/choco.png`，`study_effect_math` 对应 `icons/effect/math.png`。
