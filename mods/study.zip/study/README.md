# 妙妙生物第一弹

- 模组 id：`study`
- 版本：1
- 内容：单位 10 · 技能 12 · 效果 3

## 单位与卡面

- `study_unit_littleempire` · 皇帝小时候 → images/littleempire.png
- `study_unit_empire` · 皇帝 → images/empire.png
- `study_unit_zihan` · 赌狗 → images/zihan.png
- `study_unit_superzihan` · 圣彼得狗 → images/superzihan.png
- `study_unit_egg` · 鸡蛋仙人 → images/egg.png
- `study_unit_mad` · 疯狂完了 → images/mad.png
- `study_unit_yifei` · 逸飞巨菜 → images/yifei.png
- `study_unit_squidward` · 章鱼哥 → images/squidward.png
- `study_unit_choco` · 恐怖巧克力 → images/choco.png
- `study_unit_bgdt` · 不共戴天 → images/bgdt.png

## 技能与图标

- `study_skill_pos2` · 那就平方 → （暂无图标）
- `study_skill_yjqz` · 御驾亲征 → （暂无图标）
- `study_skill_lw` · 龙威 → （暂无图标）
- `study_skill_bite` · 赌狗咬人 → （暂无图标）
- `study_skill_kamisamabite` · 赌神咬人 → （暂无图标）
- `study_skill_mentaldamage` · 精神伤害 → （暂无图标）
- `study_skill_cf` · 去背cf → （暂无图标）
- `study_skill_ts` · 汤匙 → （暂无图标）
- `study_skill_traincrash` · traincrash → （暂无图标）
- `study_skill_bad` · 糟糕透了 → （暂无图标）
- `study_skill_choco` · 巧克力污染 → （暂无图标）
- `study_skill_bgdt` · 不共戴天 → （暂无图标）

## 效果与图标

- `study_effect_yjqz` · 御驾亲征 → （暂无图标）
- `study_effect_math` · 数论 → （暂无图标）
- `study_effect_cf` · 背诵cf → （暂无图标）

## 卡面规则

单位卡面放在 `images/`，文件名取单位 id 的最后一个字段，扩展名不限（png / jpg / webp…）。
例如 `study_unit_littleempire` 对应 `images/littleempire.jpg`。

## 图标规则

技能图标放在 `icons/skill/`，效果图标放在 `icons/effect/`；文件名取 id 的最后一个字段，扩展名不限。
例如 `study_skill_choco` 对应 `icons/skill/choco.png`，`study_effect_math` 对应 `icons/effect/math.png`。
