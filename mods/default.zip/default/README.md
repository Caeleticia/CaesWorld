# 默认包

- 模组 id：`default`
- 版本：1
- 内容：单位 2 · 技能 2 · 效果 0

## 单位与卡面

- `default_unit_slime` · 史莱姆 → images/slime.png
- `default_unit_bigslime` · 大史莱姆 → images/bigslime.png

## 技能与图标

- `default_skill_slimebeat` · 撞击 → （暂无图标）
- `default_skill_new` · 分裂 → （暂无图标）

## 卡面规则

单位卡面放在 `images/`，文件名取单位 id 的最后一个字段，扩展名不限（png / jpg / webp…）。
例如 `study_unit_littleempire` 对应 `images/littleempire.jpg`。

## 图标规则

技能图标放在 `icons/skill/`，效果图标放在 `icons/effect/`；文件名取 id 的最后一个字段，扩展名不限。
例如 `study_skill_choco` 对应 `icons/skill/choco.png`，`study_effect_math` 对应 `icons/effect/math.png`。
