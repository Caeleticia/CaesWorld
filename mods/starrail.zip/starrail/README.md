# 星穹扩展

- 模组 id：`starrail`
- 版本：1
- 内容：单位 4 · 技能 16 · 效果 6

## 单位与卡面

- `starrail_unit_castorice` · 遐蝶 → images/castorice.png
- `starrail_unit_pollux` · 「死龙」玻吕刻斯 → images/pollux.png
- `starrail_unit_hyacine` · 风堇 → images/hyacine.png
- `starrail_unit_fatfuck` · 小伊卡 → images/fatfuck.png

## 技能与图标

- `starrail_skill_cas.a` · 哀悼，死海之涟漪 → icons/skill/cas.a.png
- `starrail_skill_cas.e` · 缄默，幽蝶之轻抚 → icons/skill/cas.e.png
- `starrail_skill_cas.yj` · 月茧之庇 → icons/skill/cas.yj.png
- `starrail_skill_cas.xr` · 掌心淌过的荒芜 → icons/skill/cas.xr.png
- `starrail_skill_new` · 亡喉怒哮，苏生之颂铃 → icons/skill/new.png
- `starrail_skill_pollux.dz` · 代罪 → （暂无图标）
- `starrail_skill_pollux.xy` · 燎尽黯泽的焰息 → （暂无图标）
- `starrail_skill_pollux.hy` · 灼掠幽墟的晦翼 → （暂无图标）
- `starrail_skill_hyacine.breeze` · 当微风轻吻云沫 → （暂无图标）
- `starrail_skill_hyacine.rainbow` · 爱在虹光洒落时 → （暂无图标）
- `starrail_skill_hyacine.dawn` · 飞入晨昏的我们 → （暂无图标）
- `starrail_skill_hyacine.thunder` · 雷雨轻柔 → （暂无图标）
- `starrail_skill_fatfuck.wings` · 展翼，奔向日辉 → （暂无图标）
- `starrail_skill_fatfuck.cloud` · 阴云莞尔 → （暂无图标）
- `starrail_skill_fatfuck.sky` · 牵起晴空的手 → （暂无图标）
- `starrail_skill_fatfuck.scatter` · 乌云乌云快走开！ → （暂无图标）

## 效果与图标

- `starrail_effect_cas.md` · 月茧之庇 → icons/effect/cas.md.png
- `starrail_effect_cas.xr` · 新蕊 → icons/effect/cas.xr.png
- `starrail_effect_cas.ysmy` · 遗世冥域 → （暂无图标）
- `starrail_effect_pollux.dz` · 代罪 → （暂无图标）
- `starrail_effect_hyacine.ygtq` · 雨过天晴 → （暂无图标）
- `starrail_effect_hyacine.yc` · 云彩 → （暂无图标）

## 卡面规则

单位卡面放在 `images/`，文件名取单位 id 的最后一个字段，扩展名不限（png / jpg / webp…）。
例如 `study_unit_littleempire` 对应 `images/littleempire.jpg`。

## 图标规则

技能图标放在 `icons/skill/`，效果图标放在 `icons/effect/`；文件名取 id 的最后一个字段，扩展名不限。
例如 `study_skill_choco` 对应 `icons/skill/choco.png`，`study_effect_math` 对应 `icons/effect/math.png`。
